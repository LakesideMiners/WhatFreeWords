from setuptools import setup, find_packages

setup(
    name="whatfreewords",
    version=0.1,
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    setup_requires=[],
    data_files = [("", ["whatfreewords/word_data.txt", "whatfreewords/region_data.bin"])],
    ext_modules=[],
)
