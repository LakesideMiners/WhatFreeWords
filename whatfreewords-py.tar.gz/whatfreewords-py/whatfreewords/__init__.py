from .whatfreewords import WhatFreeWords

__all__ = (WhatFreeWords,)
